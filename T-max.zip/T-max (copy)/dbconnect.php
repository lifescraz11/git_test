<?php

$servername = "localhost";
$serveruser = "root";
$serverpass = "";
$dbname = "test";

$conn = mysqli_connect($servername,$serveruser, $serverpass, $dbname);

if(!$conn){
    die("connection not successful ". mysqli_connect_error());
}else{
    echo "Connection successful";
}