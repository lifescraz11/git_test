<?php
include_once ("dbconnect.php");

if(isset($_POST['submit'])){
    $fname = $_POST['name'];
    $email = $_POST['email'];
    $topic = $_POST['subject'];
    $text = $_POST['message'];
    $message = "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Natus, voluptatum.";

    $to = 'icetriplex@gmail.com';
    $from = 'Reply to: .$email';
    $subject= 'test mail in php';
    $body= 'You have received a message from your website contact form.\n\n'. 
    'Here are the detrails:\n\nName: $fname\n\nEmail:$email\n\Lastname: $lname\n\n message:\n$message';

    if(mail($to,$from,$body,$subject)){
        echo "mail sent";
    }else{
        echo "mail not sent";
    }
}