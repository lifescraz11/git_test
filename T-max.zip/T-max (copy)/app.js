

window.onscroll = function(){
    myFunction();
}

var navbar = document.getElementById('nav-bar');
var sticky = navbar.offsetTop;

function myFunction(){
    if(window.pageYOffset > sticky){
        navbar.classList.add("sticky")
    }else{
        navbar.classList.remove("sticky");
    }
};

var coll = document.getElementsByClassName("accordian");
var i;

for (i = 0; i< coll.length; i++){
    coll[i].addEventListener("click", function(){
        this.classList.toggle("active");
        var content = 
        this.nextElementSibling;
        if(content.style.display === "block"){
            content.style.display = "none";
        }else{
            content.style.display = "block";
        }
    });
}




// portfolio filter section

// filterSelection("all"); 


// function filterSelection(c){
//     var x,i;
//     x = document.getElementsByClassName("portfolio-item");
//     if (c == "all") c = "";
//     for (i = 0; i < x.length; i++ ) {
//         removeClass(x[i], "show");
//         if (x[i].className.indexOf(c) > -1) addClass(x[i], "show");
//     }
// }

// //Show filtered element

// function addClass(element, name){
//     var i, arr1, arr2;
//     arr1 = element.className.split("");
//     arr2 = name.split("");
//     for (i=0; i < arr2.lenght; i++){
//         if(arr1.indexOf(arr2[i])== -1){
//             element.className += "" + arr2[i];
//         }
//     }
// }

// //Hide filtered element 

// function removeClass(element, name){
//     var i, arr1,arr2;
//     arr1 = element.className.split("");
//     arr2 = name.split("");
//     for (i=0; i < arr2.lenght; i++){
//         while(arr1.indexOf(arr2[i])>-1){
//             arr1.splice(arr1.indexOf(arr2[i]), 1)
//         }
//     }
//     element.className = arr1.join("");
// }


// // Add active class to the current button

// var btnContainer = document.querySelectorAll('portfolio-filt');
// var btns = btnContainer.getElementsByClassName('filter');
// for(var i=0; i < btns.length; i++){
//     btns[i].addEventListener("click", function(){
//         var current = document.getElementsByClassName("active");
//         current[0].className.replace("active", "");
//         this.className += "active";
//     });
// }



// const observer = new IntersectionObserver((entries) => {
// entries.forEach((entry) => {
//     console.log(entry)
//     if (entry.isIntersecting) {
//         entry.target.classList.add('show');
//         }
//         else{
//             entry.target.classList.remove('show');
//         }
//     });
// });

// const hiddenElements = document.querySelectorAll('hidden');
// hiddenElements.forEach((el) => observer.observe(el));